package com.kislota.ashnaclient;

import android.app.Activity;
import android.graphics.Color;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    WebView w;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        w.setBackgroundColor(Color.parseColor("#262626"));
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // file:// origin -> any host without CORS preflight blocking
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        w.setWebChromeClient(new WebChromeClient());
        w.addJavascriptInterface(new Bridge(), "Android");
        w.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void open(String u) {
            Intent i = new Intent(MainActivity.this, SiteActivity.class);
            i.putExtra("u", u);
            startActivity(i);
        }
        @JavascriptInterface public void logout() {
            CookieManager.getInstance().removeAllCookies(null);
        }
    }

    @Override public void onBackPressed() {
        w.evaluateJavascript("window.goBack?goBack():false", v -> { if (!"true".equals(v)) finish(); });
    }
}
